<footer class="admin-footer mt-auto text-center p-4">
    <div class="admin-footer-inner d-flex justify-content-center text-center">
        <span class="admin-footer-brand"><?php echo e($siteSettings->site_name ?? 'PeerBridge'); ?></span>
        <?php if(!empty($siteSettings?->site_tagline)): ?>
            <span class="admin-footer-dot d-none d-sm-inline" aria-hidden="true">·</span>
            <span class="text-muted d-none d-sm-inline"><?php echo e($siteSettings->site_tagline); ?></span>
        <?php endif; ?>
        <span class="admin-footer-dot d-none d-sm-inline" aria-hidden="true">·</span>
        <a href="<?php echo e(url('/')); ?>" class="admin-footer-link d-none d-sm-inline">View site</a>
    </div>
</footer>
<?php /**PATH /home/yared/Desktop/Projects/peerbridge-delivery/backend/resources/views/admin/partials/footer.blade.php ENDPATH**/ ?>