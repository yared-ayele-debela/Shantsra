<?php ($pageHeading = 'Shipment Details'); ?>
<?php ($title = 'Shipment Details'); ?>


<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-8">
        <div class="card content-card mb-4">
            <div class="card-body p-4">
                <div class="d-flex flex-column flex-md-row justify-content-between gap-3 mb-4">
                    <div>
                        <div class="text-uppercase text-muted small fw-semibold mb-2">Shipment Overview</div>
                        <h4 class="mb-2"><?php echo e($shipment->from_city); ?> → <?php echo e($shipment->to_city); ?></h4>
                        <p class="text-muted mb-0">
                            Submitted <?php echo e($shipment->created_at?->diffForHumans() ?? 'recently'); ?>

                            <?php if($shipment->travel_date): ?>
                                • Preferred travel date <?php echo e($shipment->travel_date->format('M d, Y')); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="d-flex flex-column align-items-end gap-2">
                        <div class="d-flex gap-2 align-items-center">
                            <span class="badge <?php echo e(match($shipment->approval_status ?? 'pending') {
                                'approved' => 'bg-success-subtle text-success border border-success-subtle',
                                'rejected' => 'bg-danger-subtle text-danger border border-danger-subtle',
                                default => 'bg-warning-subtle text-warning-emphasis border border-warning-subtle',
                            }); ?> px-3 py-2 fs-6">
                                <i class="bi <?php echo e(match($shipment->approval_status ?? 'pending') {
                                    'approved' => 'bi-check-circle-fill me-1',
                                    'rejected' => 'bi-x-circle-fill me-1',
                                    default => 'bi-clock-history me-1',
                                }); ?>"></i>
                                <?php echo e(match($shipment->approval_status ?? 'pending') {
                                    'approved' => 'Approved Listing',
                                    'rejected' => 'Rejected Listing',
                                    default => 'Pending Approval',
                                }); ?>

                            </span>
                            <span class="badge bg-secondary-subtle text-secondary px-3 py-2 fs-6">
                                Delivery: <?php echo e(str($shipment->status)->headline()); ?>

                            </span>
                        </div>
                        <div class="d-flex gap-2">
                            <?php if(($shipment->approval_status ?? 'pending') !== 'approved'): ?>
                                <form method="POST" action="<?php echo e(route('admin.shipments.approve', $shipment)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-sm btn-success px-3 font-bold">
                                        <i class="bi bi-check-circle me-1"></i> Approve Package
                                    </button>
                                </form>
                            <?php endif; ?>
                            <?php if(($shipment->approval_status ?? 'pending') !== 'rejected'): ?>
                                <form method="POST" action="<?php echo e(route('admin.shipments.reject', $shipment)); ?>" class="d-inline" onsubmit="return confirm('Reject this shipment listing?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger px-3 font-bold">
                                        <i class="bi bi-x-circle me-1"></i> Reject
                                    </button>
                                </form>
                            <?php endif; ?>
                            <a href="<?php echo e(route('admin.shipments.edit', $shipment)); ?>" class="btn btn-sm btn-dark px-3">
                                <i class="bi bi-pencil-square me-1"></i> Edit Shipment
                            </a>
                        </div>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-sm-6">
                        <div class="border rounded-4 p-3 h-100 bg-light-subtle">
                            <div class="text-muted small mb-1">Sender</div>
                            <div class="fw-semibold"><?php echo e($shipment->sender?->name ?? 'N/A'); ?></div>
                            <div class="small text-muted"><?php echo e($shipment->sender?->email ?? 'No email available'); ?></div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="border rounded-4 p-3 h-100 bg-light-subtle">
                            <div class="text-muted small mb-1">Receiver</div>
                            <div class="fw-semibold"><?php echo e($shipment->receiver_name); ?></div>
                            <div class="small text-muted"><?php echo e($shipment->receiver_phone ?: 'No receiver phone provided'); ?></div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="border rounded-4 p-3 h-100">
                            <div class="text-muted small mb-1">Weight</div>
                            <div class="fw-semibold"><?php echo e(number_format($shipment->weight, 2)); ?> kg</div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="border rounded-4 p-3 h-100">
                            <div class="text-muted small mb-1">Images</div>
                            <div class="fw-semibold"><?php echo e(count($shipment->product_images ?? [])); ?></div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="border rounded-4 p-3 h-100">
                            <div class="text-muted small mb-1">Booking</div>
                            <div class="fw-semibold"><?php echo e($shipment->booking ? 'Matched' : 'Not matched yet'); ?></div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="border rounded-4 p-3 h-100">
                            <div class="text-muted small mb-1">Priority</div>
                            <div class="fw-semibold"><?php echo e($shipment->is_urgent ? 'Urgent' : 'Standard'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card content-card mb-4">
            <div class="card-body p-4">
                <h5 class="mb-3">Package Description</h5>
                <div class="rounded-4 border bg-light-subtle p-3">
                    <p class="mb-0 text-muted">
                        <?php echo e($shipment->description ?: 'No shipment description provided.'); ?>

                    </p>
                </div>
            </div>
        </div>

        <div class="card content-card">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center gap-3 mb-3">
                    <div>
                        <h5 class="mb-1">Product Images</h5>
                        <p class="text-muted mb-0 small">Uploaded images attached to this shipment request.</p>
                    </div>
                </div>

                <?php if(! empty($shipment->product_images)): ?>
                    <div class="row g-3">
                        <?php $__currentLoopData = $shipment->product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-xl-4">
                                <a href="<?php echo e(asset('storage/'.$image)); ?>" target="_blank" rel="noreferrer" class="text-decoration-none">
                                    <div class="border rounded-4 overflow-hidden bg-white h-100 shadow-sm">
                                        <img
                                            src="<?php echo e(asset('storage/'.$image)); ?>"
                                            alt="Shipment product image"
                                            class="w-100"
                                            style="height: 220px; object-fit: cover;"
                                        >
                                        <div class="p-3">
                                            <div class="small text-muted">Product image</div>
                                            <div class="fw-semibold text-dark">Open full size</div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="border rounded-4 p-4 text-center text-muted bg-light-subtle">
                        No product images were uploaded for this shipment.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card content-card mb-4">
            <div class="card-body p-4">
                <h5 class="mb-3">Routing & Match</h5>
                <div class="rounded-4 border p-3 mb-3">
                    <div class="text-muted small mb-1">Route</div>
                    <div class="fw-semibold"><?php echo e($shipment->from_city); ?> → <?php echo e($shipment->to_city); ?></div>
                </div>
                <div class="rounded-4 border p-3 mb-3">
                    <div class="text-muted small mb-1">Preferred travel date</div>
                    <div class="fw-semibold"><?php echo e($shipment->travel_date?->format('M d, Y') ?? 'Not specified'); ?></div>
                </div>
                <div class="rounded-4 border p-3">
                    <div class="text-muted small mb-1">Assigned traveler</div>
                    <div class="fw-semibold"><?php echo e($shipment->booking?->traveler?->name ?? 'No traveler assigned yet'); ?></div>
                    <?php if($shipment->booking): ?>
                        <div class="small text-muted mt-1">
                            Booking #<?php echo e($shipment->booking->id); ?> • <?php echo e(str($shipment->booking->status)->headline()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card content-card mb-4">
            <div class="card-body p-4">
                <h5 class="mb-3">Shipment Actions</h5>
                <a href="<?php echo e(route('admin.shipments.edit', $shipment)); ?>" class="btn btn-dark w-100 mb-3">
                    <i class="bi bi-pencil-square me-1"></i> Edit All Shipment Details
                </a>
                <hr class="my-3">
                <h6 class="mb-2 text-muted">Quick Status Update</h6>
                <form method="POST" action="<?php echo e(route('admin.shipments.update-status', $shipment)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <select name="status" class="form-select mb-3">
                        <?php $__currentLoopData = ['pending', 'accepted', 'in_transit', 'delivered']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status); ?>" <?php if($shipment->status === $status): echo 'selected'; endif; ?>>
                                <?php echo e(str($status)->headline()); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="btn btn-dark w-100">Save Status</button>
                </form>
            </div>
        </div>

        <div class="card content-card">
            <div class="card-body p-4">
                <h5 class="mb-3 text-danger">Danger Zone</h5>
                <form method="POST" action="<?php echo e(route('admin.shipments.destroy', $shipment)); ?>" onsubmit="return confirm('Delete this shipment?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-outline-danger w-100">Delete Shipment</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/yared/Desktop/Projects/peerbridge-delivery/backend/resources/views/admin/shipments/show.blade.php ENDPATH**/ ?>