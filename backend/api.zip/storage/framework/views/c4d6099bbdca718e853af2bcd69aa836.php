<?php ($pageHeading = 'Edit Shipment'); ?>
<?php ($title = 'Edit Shipment #' . $shipment->id); ?>


<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <a href="<?php echo e(route('admin.shipments.show', $shipment)); ?>" class="text-decoration-none text-muted small">
                    <i class="bi bi-arrow-left"></i> Back to Shipment Details
                </a>
                <h3 class="mb-0 mt-1">Edit Shipment Request #<?php echo e($shipment->id); ?></h3>
                <p class="text-muted small">Modify sender shipment info, route locations, weight, and delivery status for user.</p>
            </div>
            <div>
                <span class="badge bg-dark px-3 py-2">
                    Sender: <?php echo e($shipment->sender?->name ?? 'User #' . $shipment->sender_id); ?>

                </span>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.shipments.update', $shipment)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- First Photo Preview Box -->
            <div class="card content-card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-3">Shipment Photo Preview</h5>
                    <div class="d-flex align-items-center gap-4 flex-wrap">
                        <?php if($shipment->first_photo_url): ?>
                            <img src="<?php echo e($shipment->first_photo_url); ?>"
                                 alt="First Photo"
                                 class="rounded-4 border shadow-sm"
                                 style="width: 120px; height: 120px; object-fit: cover;"
                                 onerror="this.onerror=null;this.src='/assets/No-Image-Found-400x264.png';" />
                        <?php else: ?>
                            <div class="rounded-4 bg-light border d-flex align-items-center justify-content-center text-muted" style="width: 120px; height: 120px;">
                                <i class="bi bi-image fs-1"></i>
                            </div>
                        <?php endif; ?>

                        <div class="flex-grow-1">
                            <h6 class="mb-1">Package Images (<?php echo e(count($shipment->product_images ?? [])); ?> Uploaded)</h6>
                            <p class="text-muted small mb-2">Attached photos for this shipment. You can upload additional photos below.</p>
                            <input type="file" name="images[]" class="form-control form-control-sm" multiple accept="image/*">
                            <div class="form-text">Allowed formats: JPG, PNG, WEBP (max 5MB each)</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Details Card -->
            <div class="card content-card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-3">Receiver & Route Information</h5>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Receiver Name <span class="text-danger">*</span></label>
                            <input type="text" name="receiver_name" class="form-control" value="<?php echo e(old('receiver_name', $shipment->receiver_name)); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Receiver Phone</label>
                            <input type="text" name="receiver_phone" class="form-control" value="<?php echo e(old('receiver_phone', $shipment->receiver_phone)); ?>">
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Departure City (From) <span class="text-danger">*</span></label>
                            <input type="text" name="from_city" class="form-control" value="<?php echo e(old('from_city', $shipment->from_city)); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Destination City (To) <span class="text-danger">*</span></label>
                            <input type="text" name="to_city" class="form-control" value="<?php echo e(old('to_city', $shipment->to_city)); ?>" required>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Weight (kg) <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0.1" name="weight" class="form-control" value="<?php echo e(old('weight', $shipment->weight)); ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Preferred Travel Date</label>
                            <input type="date" name="travel_date" class="form-control" value="<?php echo e(old('travel_date', $shipment->travel_date?->format('Y-m-d'))); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Package Category</label>
                            <select name="category_id" class="form-select">
                                <option value="">-- Uncategorized --</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>" <?php if(old('category_id', $shipment->category_id) == $cat->id): echo 'selected'; endif; ?>>
                                        <?php echo e($cat->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Status & Priority Card -->
            <div class="card content-card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-3">Fulfillment & Status Control</h5>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Admin Approval Status <span class="text-danger">*</span></label>
                            <select name="approval_status" class="form-select fw-bold" required>
                                <option value="pending" <?php if(old('approval_status', $shipment->approval_status ?? 'pending') === 'pending'): echo 'selected'; endif; ?>>Pending Approval</option>
                                <option value="approved" <?php if(old('approval_status', $shipment->approval_status) === 'approved'): echo 'selected'; endif; ?>>Approved (Public on Frontend)</option>
                                <option value="rejected" <?php if(old('approval_status', $shipment->approval_status) === 'rejected'): echo 'selected'; endif; ?>>Rejected (Hidden)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Delivery Status <span class="text-danger">*</span></label>
                            <select name="status" class="form-select" required>
                                <?php $__currentLoopData = ['pending', 'accepted', 'in_transit', 'delivered']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($st); ?>" <?php if(old('status', $shipment->status) === $st): echo 'selected'; endif; ?>>
                                        <?php echo e(str($st)->headline()); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-12">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" name="is_urgent" value="1" id="isUrgentSwitch" <?php if(old('is_urgent', $shipment->is_urgent)): echo 'checked'; endif; ?>>
                                <label class="form-check-input-label fw-semibold text-danger ms-1" for="isUrgentSwitch">
                                    Mark as Urgent Shipment
                                </label>
                            </div>
                        </div>
                    </div>

                    <div>
                        <label class="form-label fw-semibold">Package Description</label>
                        <textarea name="description" class="form-control" rows="4" placeholder="Detailed cargo description, special handling notes..."><?php echo e(old('description', $shipment->description)); ?></textarea>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-5">
                <a href="<?php echo e(route('admin.shipments.show', $shipment)); ?>" class="btn btn-outline-secondary px-4">Cancel</a>
                <button type="submit" class="btn btn-primary px-5 font-bold">
                    <i class="bi bi-check-circle me-1"></i> Save & Update Shipment
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/yared/Desktop/Projects/peerbridge-delivery/backend/resources/views/admin/shipments/edit.blade.php ENDPATH**/ ?>