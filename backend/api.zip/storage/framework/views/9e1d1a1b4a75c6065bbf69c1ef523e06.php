<?php ($pageHeading = 'User Management'); ?>
<?php ($title = 'Users'); ?>
<?php ($pageEyebrow = 'Community Directory'); ?>
<?php ($pageSubtitle = 'Review registered users, filter by role or status, and take action quickly.'); ?>


<?php $__env->startSection('content'); ?>
<div class="card filter-card mb-4">
    <div class="card-body p-4">
        <div class="panel-heading">
            <div>
                <h5 class="mb-1 filter-title">Filter Users</h5>
                <p>Narrow the user list by keyword, account role, or lifecycle status.</p>
            </div>
        </div>
        <form method="GET" class="row g-3">
            <div class="col-12 col-md-4">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Search by name, email, phone">
            </div>
            <div class="col-6 col-md-3">
                <select name="role" class="form-select">
                    <option value="">All roles</option>
                    <option value="sender" <?php if(request('role') === 'sender'): echo 'selected'; endif; ?>>Sender</option>
                    <option value="traveler" <?php if(request('role') === 'traveler'): echo 'selected'; endif; ?>>Traveler</option>
                </select>
            </div>
            <div class="col-6 col-md-3">
                <select name="status" class="form-select">
                    <option value="">All statuses</option>
                    <option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Active</option>
                    <option value="inactive" <?php if(request('status') === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <button class="btn btn-dark w-100">Apply Filters</button>
            </div>
        </form>
    </div>
</div>

<div class="card content-card">
    <div class="card-body p-4">
        <div class="panel-heading">
            <div>
                <h5 class="mb-1">Registered Users</h5>
                <p><?php echo e($users->total()); ?> user accounts currently match your filters.</p>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table admin-table align-middle">
                <thead>
                <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th class="text-end">Actions</th></tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="fw-semibold"><?php echo e($user->name); ?></div>
                            <div class="small text-muted"><?php echo e($user->phone ?: 'No phone provided'); ?></div>
                        </td>
                        <td><?php echo e($user->email); ?></td>
                        <td><span class="status-badge bg-info-subtle text-info-emphasis"><?php echo e(ucfirst($user->role)); ?></span></td>
                        <td>
                            <span class="status-badge <?php echo e($user->status === 'active' ? 'bg-success-subtle text-success-emphasis' : 'bg-secondary-subtle text-secondary-emphasis'); ?>">
                                <?php echo e(ucfirst($user->status)); ?>

                            </span>
                        </td>
                        <td class="text-end">
                            <div class="d-flex flex-column flex-md-row gap-2 justify-content-end">
                                <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="btn btn-sm btn-outline-primary">View Profile</a>
                                <form method="POST" action="<?php echo e(route('admin.users.toggle-status', $user)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button class="btn btn-sm btn-outline-dark w-100"><?php echo e($user->status === 'active' ? 'Deactivate' : 'Activate'); ?></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-muted">No users found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-4">
            <?php echo e($users->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/yared/Desktop/Projects/peerbridge-delivery/backend/resources/views/admin/users/index.blade.php ENDPATH**/ ?>