<div class="admin-sidebar-caption">Main navigation</div>
<nav class="nav flex-column gap-1 admin-sidebar-nav">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
        <i class="bi bi-speedometer2"></i>
        <span>Dashboard</span>
    </a>
    <a href="<?php echo e(route('admin.notifications.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.notifications.*') ? 'active' : ''); ?>">
        <i class="bi bi-bell"></i>
        <span>Notifications</span>
        <?php ($unreadNavCount = \App\Models\AdminNotification::unread()->count()); ?>
        <?php if($unreadNavCount > 0): ?>
            <span class="badge bg-danger rounded-pill ms-auto"><?php echo e($unreadNavCount); ?></span>
        <?php endif; ?>
    </a>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>">
        <i class="bi bi-people"></i>
        <span>Users</span>
    </a>
    <a href="<?php echo e(route('admin.shipments.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.shipments.*') ? 'active' : ''); ?>">
        <i class="bi bi-box-seam"></i>
        <span>Shipments</span>
    </a>
    <a href="<?php echo e(route('admin.package-categories.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.package-categories.*') ? 'active' : ''); ?>">
        <i class="bi bi-tags"></i>
        <span>Package Categories</span>
    </a>
    <a href="<?php echo e(route('admin.subscription-plans.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.subscription-plans.*') ? 'active' : ''); ?>">
        <i class="bi bi-credit-card-2-front"></i>
        <span>Subscription Packages</span>
    </a>
    <a href="<?php echo e(route('admin.travels.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.travels.*') ? 'active' : ''); ?>">
        <i class="bi bi-airplane"></i>
        <span>Travels</span>
    </a>
    <a href="<?php echo e(route('admin.bookings.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.bookings.*') ? 'active' : ''); ?>">
        <i class="bi bi-journal-check"></i>
        <span>Bookings</span>
    </a>
    <a href="<?php echo e(route('admin.campaigns.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.campaigns.*') ? 'active' : ''); ?>">
        <i class="bi bi-megaphone"></i>
        <span>Campaigns</span>
    </a>
    <a href="<?php echo e(route('admin.reviews.index')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.reviews.*') ? 'active' : ''); ?>">
        <i class="bi bi-star"></i>
        <span>Reviews</span>
    </a>
    <div class="admin-sidebar-caption mt-4">Configuration</div>
    <a href="<?php echo e(route('admin.settings.website.edit')); ?>" class="admin-nav-link <?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>">
        <i class="bi bi-globe2"></i>
        <span>Website</span>
    </a>
</nav>
<?php /**PATH /home/yared/Desktop/Projects/peerbridge-delivery/backend/resources/views/admin/partials/sidebar.blade.php ENDPATH**/ ?>